Pls give credit if use... I've put alot of work into these icons. Thanx 

http://madeliniz.deviantart.com/